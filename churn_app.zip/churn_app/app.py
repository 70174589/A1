"""
app.py - Flask backend for the Customer Churn Prediction web application.

Flow: browser form -> /predict (POST) -> validate -> build one-row DataFrame
-> same preprocessing as training (AvgMonthlySpend, one-hot, column alignment,
scaling if needed) -> saved model -> friendly Churn / No Churn result page.
"""
import os
import joblib
import pandas as pd
from flask import Flask, render_template, request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model.joblib")

app = Flask(__name__)

# ------------------------------------------------------------ load artifacts
bundle = joblib.load(MODEL_PATH)
model = bundle["model"]
scaler = bundle["scaler"]
FEATURE_COLUMNS = bundle["feature_columns"]
NUM_COLS = bundle["num_cols"]
NEEDS_SCALING = bundle["needs_scaling"]
OPTIONS = bundle["category_options"]
MODEL_NAME = bundle["model_name"]

# Human readable labels for the form
LABELS = {
    "gender": "Gender", "SeniorCitizen": "Senior citizen", "Partner": "Has a partner",
    "Dependents": "Has dependents", "tenure": "Tenure (months with the company)",
    "PhoneService": "Phone service", "MultipleLines": "Multiple lines",
    "InternetService": "Internet service", "OnlineSecurity": "Online security",
    "OnlineBackup": "Online backup", "DeviceProtection": "Device protection",
    "TechSupport": "Tech support", "StreamingTV": "Streaming TV",
    "StreamingMovies": "Streaming movies", "Contract": "Contract type",
    "PaperlessBilling": "Paperless billing", "PaymentMethod": "Payment method",
    "MonthlyCharges": "Monthly charges", "TotalCharges": "Total charges",
}
INTERNET_ADDONS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
                   "TechSupport", "StreamingTV", "StreamingMovies"]
CATEGORICAL_FIELDS = list(OPTIONS.keys())


# ---------------------------------------------------------------- helpers
def parse_number(raw, name, low, high, integer=False, required=True):
    """Convert a text value to a number and check its range. Returns (value, error)."""
    raw = (raw or "").strip()
    if raw == "":
        return (None, None) if not required else (None, f"{LABELS[name]} is required.")
    try:
        value = float(raw)
    except ValueError:
        return None, f"{LABELS[name]} must be a number."
    if value != value or value in (float("inf"), float("-inf")):
        return None, f"{LABELS[name]} must be a valid number."
    if integer and value != int(value):
        return None, f"{LABELS[name]} must be a whole number."
    if not (low <= value <= high):
        return None, f"{LABELS[name]} must be between {low} and {high}."
    return (int(value) if integer else value), None


def validate(form):
    """Validate the submitted form. Returns (customer_dict, errors_list)."""
    errors, customer = [], {}

    # dropdown fields must contain one of the allowed values
    for field in CATEGORICAL_FIELDS:
        value = (form.get(field) or "").strip()
        if value == "":
            errors.append(f"Please select a value for '{LABELS[field]}'.")
        elif value not in OPTIONS[field]:
            errors.append(f"'{value}' is not a valid choice for '{LABELS[field]}'.")
        else:
            customer[field] = value

    senior = (form.get("SeniorCitizen") or "").strip()
    if senior not in ("0", "1"):
        errors.append("Please select whether the customer is a senior citizen.")
    else:
        customer["SeniorCitizen"] = int(senior)

    tenure, err = parse_number(form.get("tenure"), "tenure", 0, 100, integer=True)
    if err: errors.append(err)
    monthly, err = parse_number(form.get("MonthlyCharges"), "MonthlyCharges", 0, 500)
    if err: errors.append(err)
    total, err = parse_number(form.get("TotalCharges"), "TotalCharges", 0, 100000, required=False)
    if err: errors.append(err)

    if errors:
        return None, errors

    customer["tenure"] = tenure
    customer["MonthlyCharges"] = monthly
    # If total charges is left empty, estimate it from tenure and monthly charges.
    customer["TotalCharges"] = total if total is not None else round(tenure * monthly, 2)

    # Logical consistency rules (same structure as the training data)
    if customer["PhoneService"] == "No":
        customer["MultipleLines"] = "No phone service"
    elif customer["MultipleLines"] == "No phone service":
        errors.append("Multiple lines cannot be 'No phone service' when the customer has phone service.")
    if customer["InternetService"] == "No":
        for f in INTERNET_ADDONS:
            customer[f] = "No internet service"
    else:
        for f in INTERNET_ADDONS:
            if customer[f] == "No internet service":
                errors.append(f"'{LABELS[f]}' cannot be 'No internet service' when the customer has internet.")
    return (customer if not errors else None), errors


def preprocess(customer):
    """Apply EXACTLY the preprocessing used during training."""
    row = pd.DataFrame([customer])
    row["AvgMonthlySpend"] = row["TotalCharges"] / (row["tenure"] + 1)
    row = pd.get_dummies(row)
    row = row.reindex(columns=FEATURE_COLUMNS, fill_value=0).astype(float)
    if NEEDS_SCALING:
        row[NUM_COLS] = scaler.transform(row[NUM_COLS])
    return row


def predict(customer):
    row = preprocess(customer)
    proba = float(model.predict_proba(row)[0][1])
    label = int(model.predict(row)[0])
    return label, proba


def risk_level(p):
    if p >= 0.7: return "High"
    if p >= 0.4: return "Medium"
    return "Low"


# ----------------------------------------------------------------- routes
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", options=OPTIONS, labels=LABELS,
                           values={}, errors=[], result=None, model_name=MODEL_NAME)


@app.route("/predict", methods=["POST"])
def predict_route():
    values = request.form.to_dict()
    customer, errors = validate(request.form)
    if errors:
        return render_template("index.html", options=OPTIONS, labels=LABELS,
                               values=values, errors=errors, result=None,
                               model_name=MODEL_NAME), 400
    try:
        label, proba = predict(customer)
    except Exception:  # never show a crash page to the user
        app.logger.exception("Prediction failed")
        return render_template("index.html", options=OPTIONS, labels=LABELS, values=values,
                               errors=["Something went wrong while making the prediction. "
                                       "Please check the values and try again."],
                               result=None, model_name=MODEL_NAME), 500
    result = {
        "churn": label == 1,
        "text": "Churn" if label == 1 else "No Churn",
        "message": ("This customer is likely to leave the company. Consider a retention offer, "
                    "a longer contract or better support." if label == 1 else
                    "This customer is likely to stay with the company."),
        "probability": round(proba * 100, 1),
        "risk": risk_level(proba),
    }
    return render_template("index.html", options=OPTIONS, labels=LABELS,
                           values=values, errors=[], result=result, model_name=MODEL_NAME)


@app.errorhandler(404)
def not_found(_):
    return render_template("index.html", options=OPTIONS, labels=LABELS, values={},
                           errors=["That page does not exist. Use the form below."],
                           result=None, model_name=MODEL_NAME), 404


if __name__ == "__main__":
    app.run(debug=True)
