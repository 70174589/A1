# Deploying on PythonAnywhere (free account)

## A. Run locally first
```
pip install -r requirements.txt
python train_model.py      # recreates model.joblib (optional, already included)
python test_app.py         # all tests should PASS
python app.py              # open http://127.0.0.1:5000
```

## B. Upload to PythonAnywhere
1. Sign up at https://www.pythonanywhere.com (Beginner/free account). Your site will be `https://YOUR_USERNAME.pythonanywhere.com`.
2. **Files** tab -> upload `churn_app.zip` into your home directory.
3. **Consoles** -> *Bash*:
   ```
   unzip churn_app.zip
   cd churn_app
   pip install --user -r requirements.txt
   python train_model.py
   ```
   Running `train_model.py` on the server rebuilds `model.joblib` with the scikit-learn version installed there, which avoids pickle version-mismatch errors.
   (Do not delete `WA_Fn-UseC_-Telco-Customer-Churn.csv` before this step.)

## C. Configure the web app
1. **Web** tab -> *Add a new web app* -> *Manual configuration* -> choose a Python version (3.10+).
2. Set **Source code** and **Working directory** to `/home/YOUR_USERNAME/churn_app`.
3. Click the **WSGI configuration file** link, delete everything and paste the contents of `wsgi_pythonanywhere.py` (replace `YOUR_USERNAME`). Save.
4. If you installed packages in a virtualenv, enter its path under *Virtualenv*; with `pip install --user` no virtualenv is needed.
5. Click the green **Reload** button and open your URL.

## D. Troubleshooting
- Error page: open the **Error log** link on the Web tab.
- `ModuleNotFoundError`: run `pip install --user -r requirements.txt` again, then Reload.
- `InconsistentVersionWarning` or unpickling error: run `python train_model.py` in the project folder, then Reload.
- `FileNotFoundError: model.joblib`: the path in the WSGI file or Working directory is wrong.
- After any file change, press **Reload**.

## E. Final online test
Open the URL from your phone/another browser and test: a high-risk customer (Churn), a low-risk customer (No Churn), and an empty/invalid form (error messages).
