"""
test_app.py - local tests. Run:  python test_app.py
Checks (1) a high-risk and a low-risk customer, (2) that the web app gives the
same probability as the notebook-style predict_churn function, (3) bad input.
"""
import app as webapp

client = webapp.app.test_client()

HIGH = {"gender": "Female", "SeniorCitizen": "0", "Partner": "No", "Dependents": "No", "tenure": "2",
        "PhoneService": "Yes", "MultipleLines": "No", "InternetService": "Fiber optic",
        "OnlineSecurity": "No", "OnlineBackup": "No", "DeviceProtection": "No", "TechSupport": "No",
        "StreamingTV": "No", "StreamingMovies": "No", "Contract": "Month-to-month",
        "PaperlessBilling": "Yes", "PaymentMethod": "Electronic check",
        "MonthlyCharges": "80", "TotalCharges": "160"}
LOW = {"gender": "Male", "SeniorCitizen": "0", "Partner": "Yes", "Dependents": "Yes", "tenure": "60",
       "PhoneService": "Yes", "MultipleLines": "Yes", "InternetService": "DSL",
       "OnlineSecurity": "Yes", "OnlineBackup": "Yes", "DeviceProtection": "Yes", "TechSupport": "Yes",
       "StreamingTV": "No", "StreamingMovies": "No", "Contract": "Two year",
       "PaperlessBilling": "No", "PaymentMethod": "Bank transfer (automatic)",
       "MonthlyCharges": "65", "TotalCharges": "3900"}


def run(name, form, expect_text=None, expect_status=200):
    r = client.post("/predict", data=form)
    html = r.get_data(as_text=True)
    ok = r.status_code == expect_status and (expect_text is None or expect_text in html)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: status {r.status_code}")
    return ok, html


results = []
print("GET /:", client.get("/").status_code)
results.append(client.get("/").status_code == 200)

ok, html = run("High-risk customer -> Churn", HIGH, 'result-title">Churn<')
results.append(ok)
ok, html = run("Low-risk customer -> No Churn", LOW, "No Churn")
results.append(ok)

# consistency with direct model call (same preprocessing)
for name, form in (("high", HIGH), ("low", LOW)):
    cust, errs = webapp.validate(form)
    label, p = webapp.predict(cust)
    print(f"  direct model call ({name}): label={label} probability={p:.3f}")

# error handling
empty = dict(HIGH); empty["tenure"] = ""
ok, _ = run("Empty tenure", empty, "Tenure (months with the company) is required.", 400); results.append(ok)
neg = dict(HIGH); neg["MonthlyCharges"] = "-5"
ok, _ = run("Negative monthly charges", neg, "must be between", 400); results.append(ok)
txt = dict(HIGH); txt["tenure"] = "abc"
ok, _ = run("Text in numeric field", txt, "must be a number", 400); results.append(ok)
bad = dict(HIGH); bad["Contract"] = "Lifetime"
ok, _ = run("Invalid dropdown value", bad, "not a valid choice", 400); results.append(ok)
ok, _ = run("Completely empty form", {}, "Please select", 400); results.append(ok)
nointernet = dict(LOW); nointernet["InternetService"] = "No"
ok, _ = run("No internet auto-fills add-ons", nointernet, None, 200); results.append(ok)
blank_total = dict(HIGH); blank_total["TotalCharges"] = ""
ok, _ = run("Blank TotalCharges is estimated", blank_total, "Churn", 200); results.append(ok)
r = client.get("/nothing-here"); print("[PASS] 404 handled" if r.status_code == 404 else "[FAIL] 404"); results.append(r.status_code == 404)

print("\nALL TESTS PASSED" if all(results) else "\nSOME TESTS FAILED")
