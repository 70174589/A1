"""
train_model.py
Re-runs the Assignment 1 pipeline (same cleaning, same feature engineering,
same one-hot encoding, same 80/20 stratified split, same three models) and
saves the best model (by F1-score on the churn class) together with every
object needed to make correct predictions later.

Run once on your own computer:   python train_model.py
Output: model.joblib
"""
import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score)

RANDOM_STATE = 42
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(BASE_DIR, "WA_Fn-UseC_-Telco-Customer-Churn.csv")
XLSX_PATH = os.path.join(BASE_DIR, "WA_Fn-UseC_-Telco-Customer-Churn.xlsx")

# ---------------------------------------------------------------- 1. load
if os.path.exists(XLSX_PATH):
    df = pd.read_excel(XLSX_PATH)
else:
    df = pd.read_csv(CSV_PATH)

# ---------------------------------------------------------------- 2. clean
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce").fillna(0)
df = df.drop_duplicates()
df = df.drop(columns=["customerID"])

# ---------------------------------------------------- 3. feature engineering
data = df.copy()
data["Churn"] = data["Churn"].map({"No": 0, "Yes": 1})
data["AvgMonthlySpend"] = data["TotalCharges"] / (data["tenure"] + 1)

# Remember the allowed values of every text column (used by the web form
# dropdowns and by the server-side validation).
categorical_cols = [c for c in data.columns
                    if not pd.api.types.is_numeric_dtype(data[c]) and c != "Churn"]
# SeniorCitizen is stored as 0/1 in the dataset, so it stays numeric.
category_options = {c: sorted(data[c].unique().tolist()) for c in categorical_cols}

data_encoded = pd.get_dummies(data, drop_first=True).astype(float)
X = data_encoded.drop("Churn", axis=1)
y = data_encoded["Churn"].astype(int)

# ------------------------------------------------------------- 4. split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y)

num_cols = ["tenure", "MonthlyCharges", "TotalCharges", "AvgMonthlySpend"]
scaler = StandardScaler()
X_train_s, X_test_s = X_train.copy(), X_test.copy()
X_train_s[num_cols] = scaler.fit_transform(X_train[num_cols])
X_test_s[num_cols] = scaler.transform(X_test[num_cols])

# ------------------------------------------------------------- 5. models
models = {
    "Logistic Regression": (LogisticRegression(max_iter=1000, class_weight="balanced",
                                               random_state=RANDOM_STATE), True),
    "Decision Tree": (DecisionTreeClassifier(max_depth=5, class_weight="balanced",
                                             random_state=RANDOM_STATE), False),
    "Random Forest": (RandomForestClassifier(n_estimators=300, max_depth=8,
                                             class_weight="balanced",
                                             random_state=RANDOM_STATE, n_jobs=-1), False),
}

rows = []
for name, (model, needs_scaling) in models.items():
    Xtr = X_train_s if needs_scaling else X_train
    Xte = X_test_s if needs_scaling else X_test
    model.fit(Xtr, y_train)
    pred = model.predict(Xte)
    proba = model.predict_proba(Xte)[:, 1]
    rows.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred),
        "Recall": recall_score(y_test, pred),
        "F1-Score": f1_score(y_test, pred),
        "ROC-AUC": roc_auc_score(y_test, proba),
    })

results_df = pd.DataFrame(rows).set_index("Model").round(3)
print(results_df)

best_name = results_df["F1-Score"].idxmax()
best_model, best_scaled = models[best_name]
print("\nBest model by F1-Score:", best_name)

# ------------------------------------------------------------- 6. save
bundle = {
    "model": best_model,
    "model_name": best_name,
    "needs_scaling": best_scaled,
    "scaler": scaler,
    "feature_columns": X.columns.tolist(),   # exact training column order
    "num_cols": num_cols,
    "category_options": category_options,
    "metrics": results_df.loc[best_name].to_dict(),
}
joblib.dump(bundle, os.path.join(BASE_DIR, "model.joblib"))
results_df.to_csv(os.path.join(BASE_DIR, "model_comparison.csv"))
print("Saved model.joblib with", len(bundle["feature_columns"]), "features")
print("Category options:", category_options)
