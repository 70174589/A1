# Paste the contents of this file into the WSGI configuration file on PythonAnywhere
# (Web tab -> "WSGI configuration file"), replacing everything inside it.
# Change YOUR_USERNAME to your PythonAnywhere username.
import sys

path = "/home/YOUR_USERNAME/churn_app"
if path not in sys.path:
    sys.path.insert(0, path)

from app import app as application  # noqa: E402
